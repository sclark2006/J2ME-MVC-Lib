package com.fclark.mob.lends.controllers;

import java.util.Enumeration;
import com.fclark.mob.db.Entity;

public abstract class Controller {
	private Class modelClass;
	public abstract int getIndexById(Entity model);
	
	public Entity create() {
		if(modelClass == null)
			return null;
		try {
			return (Entity) modelClass.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} 
	}
	
	
	public abstract Enumeration findAll();
	public abstract Enumeration findBy(String field, int sentidoOrden);
	public abstract Entity findById(int id);
	public abstract Entity findByRecordId(int id);
	
	public boolean save(Entity model) {
		return false;		
	}
	
	public void delete(Entity model) {
		
	}
}
