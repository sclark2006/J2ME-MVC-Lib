/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fclark.mob.lends.models;

/**
 *
 * @author Frederick
 * @version 06/17/2011 08:38:55 PM
 */
import com.fclark.mob.db.Entity;
import com.fclark.mob.db.Field;
import com.fclark.util.List;
import com.fclark.util.TimeSpan;
import java.util.Calendar;
import java.util.Date;

public class Person extends Entity {
  
    public static final Field NAME =  new Field(1, Field.STRING);
    public static final Field ADDRESS = new Field(2, Field.STRING);
    public static final Field PHONE = new Field(3, Field.STRING);
    public static final Field EMAIL = new Field(4, Field.STRING);
    public static final Field BIRTHDATE = new Field(5, Field.DATE);
    public static final Field BALANCE = new Field(6, Field.DOUBLE);

    // ////////////////////////////////
    public Person() {
        super(new Field[]{NAME, ADDRESS, PHONE, EMAIL, BIRTHDATE, BALANCE});
    }

    public Person(Field[] fields) {
        super(fields);
    }
    
    // /////////////////////////////////
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result
                + ((get(NAME) == null) ? 0 : get(NAME).hashCode());
        return result;
    }

    public int age() {
        TimeSpan age = TimeSpan.between(new Date(), this.getDate(BIRTHDATE));
        if(age == null)
            return 1;        
        return age.getYears();
    }     
            
    public String toString() {
        return getInt(ID) + " " + get(NAME) + " " + age();
    }

    public static int count() {
        return Entity.count(getStoreName(Person.class));
    }
    
    public static List findAll() {
        return Entity.findAll(Person.class);
    }
    
    public static List findAll(Field orderBy, int sortType) {
        return Entity.findAll(Person.class, orderBy, sortType);
    }
    
    public static Person findById(int id) { 
        return (Person) Entity.findById(Person.class, id); 
    }
    
    public static Person findByRecordId(int recordId) {
        return (Person) Entity.findByRecordId(Person.class,recordId);
    }
    
    public static List findBy(Field field, Object value) {
        return Entity.findBy(Person.class, field, value);
    }
    
    public static List findBy(Field field, Object value, Field orderBy, int sortType) {
        return Entity.findBy(Person.class, field, value, orderBy, sortType);
    }
    
}
