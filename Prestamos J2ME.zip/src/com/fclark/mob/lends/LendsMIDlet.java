package com.fclark.mob.lends;

import com.fclark.mob.lends.models.Person;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.DateField;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Gauge;
import javax.microedition.lcdui.Item;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.Ticker;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

import com.fclark.util.Collections;
import com.fclark.util.DisplayManager;
import java.util.Hashtable;

public class LendsMIDlet extends MIDlet implements CommandListener {

    private static final String MSG_FELIZ_CUMPLEA�OS = "!Feliz cumplea�os para ";
    private static final String MSG_NO_HAY_CUMPLEA�OS = "No hay cumplea�os para el d�a de hoy!";
    private static final String MSG_CONTACTO_ELIMINADO = "Contacto eliminado!";
    private static final String MSG_ESPECIFICAR_NOMBRE = "Debe especificar el nombre de la persona";
    private static final String MSG_ESPECIFICAR_EDAD = "Debe especificar la edad de la persona";
    private static final String MSG_MAYORIA_DE_EDAD = "La persona debe tener 18 a�os o m�s";
    private static final String MSG_GUARDADO = "Contacto guardado satisfactoriamente!";
    private static final String MSG_NO_GUARDADO = "El contacto no pudo ser guardado!";
    private DisplayManager manager;
    private List mainList;
    private Form editorForm;
    private List screen3;
    private Alert alert;
    private Command exitCommand;
    private Command backCommand;
    private Command createCommand;
    private Command saveCommand;
    private Command deleteCommand;
    private Command sortCommand;
    private Command showBirthdaysCommand;
    private Person contactoActual;
    private int siguienteOrden;
    private boolean isShowingBirthdays;
    
    private Hashtable controllersMap;

    /**
     * Creates several screens and navigates between them.
     */
    public LendsMIDlet() {
        this.manager = new DisplayManager(Display.getDisplay(this));
        //this.controllersMap = new Hashtable();
        //Commands
        this.exitCommand = new Command("Salir", Command.EXIT, 0);
        this.sortCommand = new Command("Ordenar (Edad)", Command.ITEM, 1);
        this.createCommand = new Command("Agregar", Command.OK, 2);
        this.deleteCommand = new Command("Eliminar", Command.ITEM, 3);
        this.showBirthdaysCommand = new Command("Cumplea�os", Command.ITEM, 3);
        ////////////////////////////
        this.backCommand = new Command("Volver", Command.BACK, 0);
        this.saveCommand = new Command("Guardar", Command.ITEM, 1);
        

        //Pantalla de Listar Contactos
        this.mainList = getMainList();
        this.mainList.setCommandListener(this);
        this.mainList.addCommand(this.exitCommand);
        this.mainList.addCommand(this.createCommand);
        this.mainList.addCommand(this.deleteCommand);
        this.mainList.addCommand(this.sortCommand);
        this.mainList.addCommand(this.showBirthdaysCommand);
        this.mainList.setSelectCommand(List.SELECT_COMMAND);
        //controllersMap.put(mainList, alert) 

        //Pantalla de agregar/editar contactos
        this.editorForm = getEditorForm();
        this.editorForm.setCommandListener(this);
        this.editorForm.addCommand(this.backCommand);
        this.editorForm.addCommand(this.saveCommand);
        this.editorForm.addCommand(this.createCommand);
        this.editorForm.addCommand(this.deleteCommand);
        siguienteOrden = Collections.ORDER_ASCENDING;
        contactoActual = null;
        isShowingBirthdays = false;
    }

    private List getMainList() {
        if (this.mainList == null) {
            return new List("Contactos", List.IMPLICIT);
        } else {
            return this.mainList;
        }
    }

    private Form getEditorForm() {
        return new Form("Client", new Item[]{
                    new TextField("Name: *", null, 15, TextField.ANY),
                    new TextField("Address:", null, 20, TextField.ANY),
                    new TextField("Phone:", null, 15, TextField.PHONENUMBER),
                    new TextField("e-mail:", null, 30, TextField.EMAILADDR),
                    new DateField("Birthdate: *", DateField.DATE),
                    new TextField("Age:", null, 3, TextField.NUMERIC + TextField.UNEDITABLE),                    
                    new TextField("Balance:", null, 10, TextField.DECIMAL)
                });
    }

    private List getDeletionList() {
        if (this.screen3 == null) {
            return new List("Select for delete", List.MULTIPLE);
        } else {
            return this.screen3;
        }
    }

    private Alert getAlert() {
        if (this.alert == null) {
            return new Alert("Alerta: ");
        } else {
            return this.alert;
        }
    }

    /* (non-Javadoc)
     * @see javax.microedition.midlet.MIDlet#startApp()
     */
    protected void startApp() throws MIDletStateChangeException {
        listar();
    }

    /* (non-Javadoc)
     * @see javax.microedition.lcdui.CommandListener#commandAction(javax.microedition.lcdui.Command, javax.microedition.lcdui.Displayable)
     */
    public void commandAction(Command command, Displayable displayable) {
        if(command.equals(createCommand)) actionCreate(displayable);
        //agregar
        if (command.equals(this.createCommand)) {
            contactoActual = ClientsManager.create();
            this.editorForm.setTitle("Nuevo Contacto");
            if (displayable.equals(mainList)) {
                this.manager.next(this.editorForm);
            } else if (displayable.equals(editorForm)) {
                limpiarPantalla(editorForm);
            }
        } //volver
        else if (command.equals(this.backCommand)) {
            this.manager.back();
        } //guardar
        else if (command.equals(this.saveCommand)) {
            guardar();
        } //eliminar
        else if (command.equals(this.deleteCommand)) {
            if (displayable.equals(mainList)) {
                this.screen3 = getDeletionList();
            }
            if (displayable.equals(editorForm)) {
                eliminar();
            }
        } //ordenar
        else if (command.equals(this.sortCommand)) {
            ordenar("edad", siguienteOrden);
            if (siguienteOrden == Collections.ORDER_ASCENDING) {
                siguienteOrden = Collections.ORDER_DESCENDING;
            } else {
                siguienteOrden = Collections.ORDER_ASCENDING;
            }

        } //cumplea�os
        else if (command.equals(showBirthdaysCommand)) {
            notificarCumplea�os();
        } //salir
        else if (command.equals(this.exitCommand)) {
            this.notifyDestroyed();
        } //seleccionar
        else if (command.equals(List.SELECT_COMMAND)) {
            if (displayable.equals(mainList)) {
                desplegarSeleccion(mainList.getSelectedIndex());
            }
            if (displayable.equals(screen3)) {
                eliminarGrupo();
            }
        }
    }

    private void notificarCumplea�os() {
        if (this.mainList.getTicker() == null) {
            this.mainList.setTicker(new Ticker("Felicidades:"));
        }
        Persona persona = new Persona();
        persona.setFechaNacimiento(new Date());
        Vector cumplea�eros = ClientsManager.findBy("fechaNacimiento", persona);
        StringBuffer msgBuilder = new StringBuffer();
        if (cumplea�eros.isEmpty()) {
            msgBuilder.append(MSG_NO_HAY_CUMPLEA�OS);
        } else {
            msgBuilder.append(MSG_FELIZ_CUMPLEA�OS);
            boolean primer = true;
            Enumeration enumCumple = cumplea�eros.elements();
            while (enumCumple.hasMoreElements()) {
                if (!primer) {
                    msgBuilder.append(", ");
                }
                msgBuilder.append(((Persona) enumCumple.nextElement()).getNombre());
                primer = false;
            }
        }
        isShowingBirthdays = true;
        this.mainList.getTicker().setString(msgBuilder.toString());
    }

    private void desplegarSeleccion(int index) {
        contactoActual = ClientsManager.findByIndex(index);
        llenarPantallaConObjeto(editorForm, contactoActual);
        this.manager.next(this.editorForm);
    }

    private void eliminar() {
        if (contactoActual != null) {
            contactoActual.delete();
            desplegarMensaje(MSG_CONTACTO_ELIMINADO);
            listar();
        }
    }

    private void eliminarGrupo() {
        //screen1.setSelectCommand(command)
    }

    private void listar() {
        llenarLista(this.mainList, ClientsManager.findAll().elements());
        this.manager.next(mainList);
    }

    private void ordenar(String ordenarPor, int sentidoOrden) {
        llenarLista(this.mainList, ClientsManager.sort(ordenarPor, sentidoOrden).elements());
        this.manager.next(mainList);
    }

    private void guardar() {
        if (contactoActual != null) {
            llenarObjetoConDatos(contactoActual, editorForm);
            //Validaciones
            if (contactoActual.getNombre() == null) {
                desplegarMensaje(MSG_ESPECIFICAR_NOMBRE);
                return;
            }
            if (contactoActual.getEdad() == 0) {
                desplegarMensaje(MSG_ESPECIFICAR_EDAD);
                return;
            } else if (contactoActual.getEdad() < 18) {
                desplegarMensaje(MSG_MAYORIA_DE_EDAD);
                return;
            }
            //Guarda el contacto						
            if (contactoActual.save()) {
                desplegarMensaje(MSG_GUARDADO);
                listar();
            } else {
                desplegarMensaje(MSG_NO_GUARDADO);
            }
        }
    }

    protected void destroyApp(boolean unconditional) throws MIDletStateChangeException {
    }

    protected void pauseApp() {
    }

    /// 
    private void desplegarMensaje(String mensaje) {
        this.alert = getAlert();
        this.alert.setString(mensaje);
        this.alert.setTimeout(2000);
        this.manager.next(this.alert);
    }

    private void limpiarPantalla(Displayable disp) {
        if (disp instanceof Form) {
            Form form = (Form) disp;
            try {
                for (int i = 0;; i++) {
                    if (form.get(i) instanceof TextField) {
                        ((TextField) form.get(i)).setString(null);
                    } else if (form.get(i) instanceof DateField) {
                        ((DateField) form.get(i)).setDate(null);
                    }
                }
            } catch (Exception e) {
            }
        }//
        else if (disp instanceof List) {
            ((List) disp).deleteAll();
        }
    }

    private Object obtieneValor(Item item) {
        Object result = null;
        if (item instanceof TextField) {
            result = ((TextField) item).getString();
        } else if (item instanceof DateField) {
            result = ((DateField) item).getDate();
        } else if (item instanceof StringItem) {
            result = ((StringItem) item).getText();
        } else if (item instanceof Gauge) {
            result = new Integer(((Gauge) item).getValue());
        }

        return result;
    }

    private void ajustaValor(Item item, Object valor) {
        if (item instanceof TextField) {
            String valorFinal = null;
            if (valor instanceof String) {
                valorFinal = (String) valor;
            } else {
                if (valor != null) {
                    valorFinal = valor.toString();
                }
            }
            ((TextField) item).setString(valorFinal);
        } else if (item instanceof DateField) {
            ((DateField) item).setDate((Date) valor);
        } else if (item instanceof StringItem) {
            ((StringItem) item).setText((String) valor);
        } else if (item instanceof Gauge) {
            ((Gauge) item).setValue(((Integer) valor).intValue());
        }
    }

    private void llenarPantallaConObjeto(Displayable disp, Persona contacto) {
        if (disp.equals(editorForm)) {
            ajustaValor(editorForm.get(0), contacto.getNombre());
            ajustaValor(editorForm.get(1), contacto.getDireccion());
            ajustaValor(editorForm.get(2), contacto.getTelefono());
            ajustaValor(editorForm.get(3), contacto.getEmail());
            ajustaValor(editorForm.get(4), new Integer(contacto.getEdad()));
            ajustaValor(editorForm.get(5), contacto.getFechaNacimiento());
            ajustaValor(editorForm.get(6), new Double(contacto.getBalance()));
        }
    }

    private void llenarObjetoConDatos(Persona contacto, Displayable disp) {
        if (disp.equals(editorForm)) {
            contacto.setNombre(obtieneValor(editorForm.get(0)).toString());
            contacto.setDireccion(obtieneValor(editorForm.get(1)).toString());
            contacto.setTelefono(obtieneValor(editorForm.get(2)).toString());
            contacto.setEmail(obtieneValor(editorForm.get(3)).toString());
            String edadStr = (String) obtieneValor(editorForm.get(4));
            if (edadStr == null) {
                edadStr = "0";
            }
            contacto.setEdad(Integer.valueOf(edadStr).intValue());
            contacto.setFechaNacimiento((Date) obtieneValor(editorForm.get(5)));
            String balanceStr = (String) obtieneValor(editorForm.get(6));
            if (balanceStr == null) {
                balanceStr = "0.0";
            }
            contacto.setBalance(Double.valueOf(balanceStr).doubleValue());
        }
    }

    private void llenarLista(List lista, Enumeration e) {
        lista.deleteAll();
        while (e.hasMoreElements()) {
            lista.append(e.nextElement().toString(), null);
        }

        if (isShowingBirthdays) {
            notificarCumplea�os();
        }
    }

    private void actionCreate(Displayable displayable) {
         contactoActual = ClientsManager.create();
            this.editorForm.setTitle("Nuevo Contacto");
            if (displayable.equals(mainList)) {
                this.manager.next(this.editorForm);
            } else if (displayable.equals(editorForm)) {
                limpiarPantalla(editorForm);
            }
    }
}
