package com.fclark.mob.db;

import com.fclark.util.Collections;
import com.fclark.util.List;

public abstract class Entity extends AbstractRecord {

    public static final Field ID = new Field(0, Field.INT);
    private String entityName;

    protected Entity(Field[] metaData) {
        this.metaData = new Field[metaData.length + 1];
        this.metaData[0] = ID;
        System.arraycopy(metaData, 0, this.metaData, 1, metaData.length);
        data = new Object[this.metaData.length];
    }

    public void setStoreName(String name) throws IllegalArgumentException {
        if(this.entityName != null)
            throw new IllegalArgumentException("Entity name already defined!");
        if (name.length() > 32) {
            throw new IllegalArgumentException("Entity name too long. Should not be longer than 32 characters");
        }
        this.entityName = name;
    }

    public String getStoreName() {
        if (this.entityName == null) {
            this.entityName = getStoreName(this.getClass());
        }
        return this.entityName;
    }

    public boolean create() {
        return Database.createRecord(this);
    }

    public boolean exists() {
        return Database.recordExists(this);
    }//exists

    public boolean save() {
        if (!update()) {
            return create();
        } else {
            return true;
        }
    }

    public boolean delete() {
        return Database.deleteRecord(this);
    }
    
    private boolean update() {
        return Database.updateRecord(this);
    }

    private Entity refresh() {
        Database.refreshRecord(this);
        return this;
    }

    // ///////////////////////////////////////////////////////////
    public int compareTo(Object object) {
        if (object == null) {
            throw new NullPointerException();
        }

        int result;
        Entity entity = (Entity) object;
        try {
            if (this.getInt(ID) > 0 && entity.getInt(ID) > 0) {
                result = this.getInt(ID) - entity.getInt(ID);
            } else {
                result = this.getRecordId() - entity.getRecordId();
            }
        } catch (Exception e) {
            result = this.getRecordId() - entity.getRecordId();
        }
        entity = null;
        return result;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Entity other = (Entity) obj;
        if (this.getRecordId() != other.getRecordId()) {
            other = null;
            return false;
        }
        if (this.getInt(ID) != other.getInt(ID)) {
            other = null;
            return false;
        }
        other = null;
        return true;
    }

    public int hashCode() {
        final int prime = 31;
        int result = 1;
        try {
            if (getRecordId() > 0) {
                result = prime * result + getRecordId();
            } else {
                result = prime * result + this.getInt(ID);
            }
        } catch (Exception e) {
            result = prime * result + ((Object) data).hashCode();
        }
        return result;
    }
    
    ////////////////////////////////////////////////////////////////////////////

    public static Entity newInstance(Class entityClass) {
        if (Entity.class.isAssignableFrom(entityClass)) {
            try {
                return (Entity) entityClass.newInstance();
            } catch (Exception e) {
                e.printStackTrace();
                throw new ClassCastException(e.getMessage());
            }
        } else {
            throw new ClassCastException();
        }
    }

    public static String getStoreName(Class entityClass) {
        String entityName = entityClass.getName();
        int dot = entityName.indexOf('.');
        if (dot > 0) {
            entityName = entityName.substring(dot);
        }

        if (entityName.length() > 32) {
            entityName = entityName.substring(0, 30).concat("_");
        }

        return entityName;
    }
    
    public static int count() {
        throw new java.lang.IllegalArgumentException("You can't call this method from this class");
    }

    protected static int count(String entityName) {
        return Database.countRecords(entityName);
    }
    
    public static List findAll() {
        throw new java.lang.IllegalArgumentException("You can't call this method from this class");
    }
    
    protected static List findAll(Class entityClass) {
        return Database.getRecordList(entityClass);
    }
    
    public static List findAll(Field orderBy, int sortType) {
        throw new java.lang.IllegalArgumentException("You can't call this method from this class");
    }
    
    protected static List findAll(Class entityClass, Field orderBy, int sortType) {
        try {
            return Database.getRecordList(entityClass,null,new EntityFieldComparator(entityClass, orderBy, sortType));
        } catch (Exception ex) {
            return Collections.EMPTY_LIST;
        }
    }
    
//    public static Entity findById(int id) {
//        throw new java.lang.IllegalArgumentException("You can't call this method from this class");
//    }
        
    protected static Entity findById(Class entityClass, int id) {
        try {
            return (Entity) Database.getFirstRecord(entityClass, new EntityIDFilter(id), null);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    
//    public static Entity findByRecordId(int id) {
//        throw new java.lang.IllegalArgumentException("You can't call this method from this class");
//    }
        
    protected static Entity findByRecordId(Class entityClass, int id) {
        try {
            return (Entity) Database.getRecord(entityClass, id);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static List findBy(Field field, Object value) {
        throw new java.lang.IllegalArgumentException("You can't call this method from this class");
    }
    
    protected static List findBy(Class entityClass, Field field, Object value){
        try {
            return Database.getRecordList(entityClass, new EntitylFieldFilter(entityClass, field, value), null);
        } catch (Exception ex) {
            ex.printStackTrace();
            return Collections.EMPTY_LIST;
        }
    }
    
    public static List findBy(Field field, Object value, Field orderBy, int sortType) {
        throw new java.lang.IllegalArgumentException("You can't call this method from this class");
    }
    
    protected static List findBy(Class entityClass, Field field, Object value, Field orderBy, int sortType){
        try {
            return Database.getRecordList(entityClass, new EntitylFieldFilter(entityClass, field, value), 
                    new EntityFieldComparator(entityClass, orderBy, sortType));
        } catch (Exception ex) {
            ex.printStackTrace();
            return Collections.EMPTY_LIST;
        }
    }
    

}//class
