package com.fclark.util;

public interface Comparable {
	int compareTo(Object object);
}
